| `Version` | `Update Notes`                    |
|-----------|-----------------------------------|
| 1.0.1     | - Fix image in the README.md file |
| 1.0.0     | - Initial Release                 |